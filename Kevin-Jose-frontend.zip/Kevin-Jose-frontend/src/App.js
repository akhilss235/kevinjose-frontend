import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Dashboard from "../src/Compontes/Dashboard";
import withSideBarLayout from "../src/Navbar/Sidebar";
import Propertiess from "../src/Compontes/Propertiess";
import Enquired from "../src/Compontes/Enquired";
import Signedin from "../src/Compontes/Signedin ";
import Employeeprofile from "../src/Compontes/Employeeprofile";
import Attendance from "../src/Compontes/Attendance";
import Expense from "../src/Compontes/Expense ";
import Selling from "../src/Pages/Selling";
import Employee from "../src/Pages/Employee";
import EmployeeDetails from "../src/Pages/EmployeeDetails";
import Attendancecal from "../src/Pages/Attendancecal";
import ExpenseAdd from "../src/Pages/ExpenseAdd";
import AddEmployee from "../src/Pages/AddEmployee";
import AddEmployeUpdate from "../src/Pages/AddEmployeUpdate";
import Propertiessatues from "../src/Pages/Propertiessatues";
import Loading from "../src/modal/spinner";
import Admin from "../src/Compontes/Admin";
function App() {
  const [showOTPBox, setShowOTPBox] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, [loading]);

  if (loading) {
    return <Loading />;
  }

  return (
    <div className="App">
      <Router>
        <Routes>
          {/*  */}
          <Route path="/" element={<Admin />} />
          <Route path="/Admin" element={<Admin />} />

          <Route
            path="/Dashboard"
            element={withSideBarLayout(<Dashboard />, true)}
          />
          <Route
            path="/Propertiess"
            element={withSideBarLayout(<Propertiess />, true)}
          />
          <Route
            path="/Enquired"
            element={withSideBarLayout(<Enquired />, true)}
          />
          <Route
            path="/Signedin"
            element={withSideBarLayout(<Signedin />, true)}
          />
          <Route
            path="/Employeeprofile"
            element={withSideBarLayout(<Employeeprofile />, true)}
          />
          <Route
            path="/Attendance"
            element={withSideBarLayout(<Attendance />, true)}
          />
          <Route
            path="/Expense"
            element={withSideBarLayout(<Expense />, true)}
          />

          {/* useNavigate PATH PAGES */}
          <Route
            path="/Selling/:id"
            element={withSideBarLayout(<Selling />, true)}
          />
          <Route
            path="/Employee/:user_id"
            element={withSideBarLayout(<Employee />, true)}
          />
          <Route
            path="/EmployeeDetails/:employee_code"
            element={withSideBarLayout(<EmployeeDetails />, true)}
          />
          <Route
            path="/Attendancecal/:employee_code"
            element={withSideBarLayout(<Attendancecal />, true)}
          />
          <Route
            path="/ExpenseAdd"
            element={withSideBarLayout(<ExpenseAdd />, true)}
          />

          <Route
            path="/AddEmployee"
            element={withSideBarLayout(<AddEmployee />, true)}
          />
          <Route
            path="/AddEmployeUpdate/:employee_code"
            element={withSideBarLayout(<AddEmployeUpdate />, true)}
          />
          <Route
            path="/Propertiessatues/:id"
            element={withSideBarLayout(<Propertiessatues />, true)}
          />
        </Routes>
      </Router>
      <ToastContainer />
    </div>
  );
}

export default App;
