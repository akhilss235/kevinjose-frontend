import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import AddressForm from "../Pages/AddressForm";
import Form from "react-bootstrap/Form";
import { Row, Col, Button } from "react-bootstrap"; // Add this line

const EmployeeForm = () => {
  // Initialize employeeCodeOptions as an empty array
  const [employee, setEmployee] = useState({
    Name: "",
    EmployeeCode: "2024SI003",
    Designation: "",
    ProfileImage: null,
    JoiningDate: "",
    Gender: "",
    EducationQualification: [{ pdf: null, degree: "" }],
    PhoneNumber: "",
    MaritalStatus: "",
    AlternativePhoneNumber: "",
    EmailOffice: "",
    EmailPersonal: "",
    BloodGroup: "",
    AadhaarNumber: "",
    AddressPresent: {
      AddressLine1: "",
      AddressLine2: "",
      City: "",
      District: "",
      State: "",
      Country: "",
      ZipCode: "",
    },
    AddressPermanent: {
      AddressLine1: "",
      AddressLine2: "",
      City: "",
      District: "",
      State: "",
      Country: "",
      ZipCode: "",
    },
    AccountNumber: "",
    IFSCCode: "",
    BankName: "",
    PANNumber: "",
    Status: "",
    Username: "ssssssss",
    Password: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Function to handle form input changes
  const handleChange = (event) => {
    const { name, value } = event.target;
    console.log("Field changed:", name, value); // Log to see what’s being changed
    setEmployee((prevEmployee) => ({ ...prevEmployee, [name]: value }));
  };

  // Function to handle education qualification input changes
  const handleEducationChange = (index, event) => {
    const { name, value } = event.target;
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      EducationQualification: prevEmployee.EducationQualification.map(
        (education, i) =>
          i === index ? { ...education, [name]: value } : education
      ),
    }));
  };

  // Function to handle file changes for education qualification
  const handleCertificationFileChange = (index, event) => {
    const file = event.target.files[0];
    if (file && file.type.toLowerCase() === "application/pdf") {
      setEmployee((prevEmployee) => ({
        ...prevEmployee,
        EducationQualification: prevEmployee.EducationQualification.map(
          (education, i) =>
            i === index ? { ...education, pdf: file } : education
        ),
      }));
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`EducationQualification[${index}].pdf`]: "",
      }));
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`EducationQualification[${index}].pdf`]:
          "Only PDF files are supported",
      }));
    }
  };

  // Function to handle profile image change
  const handleProfileImageChange = (event) => {
    const file = event.target.files[0];
    setEmployee((prevEmployee) => ({ ...prevEmployee, ProfileImage: file }));
    setErrors((prevErrors) => ({ ...prevErrors, ProfileImage: "" }));
  };

  // Function to handle address changes
  const handleAddressChange = (addressType, field, value) => {
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      [addressType]: {
        ...prevEmployee[addressType],
        [field]: value,
      },
    }));
  };

  // Validate the form before submitting
  const validateForm = () => {
    const errors = {};
    if (!employee.Name.trim()) errors.Name = "Name is required";
    if (!employee.Password.trim()) errors.Password = "Password is required";
    else if (employee.Password.trim().length < 8)
      errors.Password = "Password should be at least 8 characters long";
    if (!employee.ProfileImage) errors.ProfileImage = "Photo is required";
    if (!employee.JoiningDate) errors.JoiningDate = "Joining date is required";
    if (!employee.Gender) errors.Gender = "Gender is required";
    if (!employee.MaritalStatus)
      errors.MaritalStatus = "Marital status is required";
    if (!employee.PhoneNumber) errors.PhoneNumber = "Phone number is required";
    if (!employee.AlternativePhoneNumber)
      errors.AlternativePhoneNumber = "Alternative phone number is required";
    if (!employee.EmailOffice) errors.EmailOffice = "Office email is required";
    if (!employee.EmailPersonal)
      errors.EmailPersonal = "Personal email is required";
    if (!employee.BloodGroup) errors.BloodGroup = "Blood group is required";
    if (!employee.AadhaarNumber)
      errors.AadhaarNumber = "Aadhaar number is required";
    if (!employee.AccountNumber)
      errors.AccountNumber = "Account number is required";
    if (!employee.IFSCCode) errors.IFSCCode = "IFSC Code is required";
    if (!employee.BankName) errors.BankName = "Bank name is required";
    if (!employee.PANNumber) errors.PANNumber = "PAN number is required";
    if (!employee.Designation) errors.Designation = "Designation is required";

    employee.EducationQualification.forEach((education, index) => {
      if (!education.degree.trim())
        errors[`EducationQualification[${index}].degree`] =
          "Degree is required";
      if (!education.pdf)
        errors[`EducationQualification[${index}].pdf`] =
          "Certification PDF is required";
    });

    if (!employee.AddressPresent.AddressLine1.trim())
      errors.AddressPresent_AddressLine1 = "Present address line 1 is required";
    if (!employee.AddressPermanent.AddressLine1.trim())
      errors.AddressPermanent_AddressLine1 =
        "Permanent address line 1 is required";

    return errors;
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
  
    const formData = new FormData();
    // Append fields
    Object.entries(employee).forEach(([key, value]) => {
      if (key !== "EducationQualification" && key !== "AddressPresent" && key !== "AddressPermanent") {
        formData.append(key, value);
      }
    });
  
    // Append addresses
    ['AddressPresent', 'AddressPermanent'].forEach(addr => {
      Object.entries(employee[addr]).forEach(([key, value]) => {
        formData.append(`${addr}.${key}`, value);
      });
    });
  
    // Append education
    employee.EducationQualification.forEach((edu, index) => {
      formData.append(`EducationQualification[${index}].degree`, edu.degree);
      if (edu.pdf) formData.append(`EducationQualification[${index}].pdf`, edu.pdf);
    });
  
    try {
      const response = await axios.post("http://localhost:6060/api/profiles/create/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      toast.success("Employee added successfully");
      navigate("/Employeeprofile");
    } catch (error) {
      const errorMsg = error.response ? error.response.data : error.message;
      toast.error(`Failed to add employee: ${errorMsg}`);
    }
  };
  
  // const [loading, setLoading] = useState(true); 
  // useEffect(() => {
  //   const fetchData = async () => {
  //     setLoading(true); 
  //     try {
  //       const response = await axios.get(
  //         "http://localhost:6060/api/profiles/employee_code_generated/"
  //       );
  //       console.log("Fetched data:", response.data); 
  //       setEmployee((prevEmployee) => ({
  //         ...prevEmployee,
  //         EmployeeCode: response.data.EmployeeCode,
  //       }));
  //     } catch (err) {
  //       console.error("Error fetching employee code:", err); 
  //     } finally {
  //       setLoading(false); 
  //     }
  //   };

  //   fetchData();
  // }, []);

  return (
    <Form onSubmit={handleSubmit}>
      <Row>
        <Col>
          <div>
            <label>Name:</label>
            <Form.Control
              type="text"
              name="Name"
              value={employee.Name}
              onChange={handleChange}
              isInvalid={!!errors.Name}
            />
            <Form.Control.Feedback type="invalid">
              {errors.Name}
            </Form.Control.Feedback>
          </div>
        </Col>
        <Col>
          {/* <div>
            <label>Employee Code:</label>

            <Form.Control
              type="text"
              name="employee.EmployeeCode"
              value={employee.EmployeeCode}
              readOnly
            />
       
          </div> */}
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Designation:</label>
            <Form.Control
              type="text"
              name="Designation"
              value={employee.Designation}
              onChange={handleChange}
            />
            {errors.Designation && <p>{errors.Designation}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>Joining Date:</label>
            <Form.Control
              type="date"
              name="JoiningDate"
              value={employee.JoiningDate}
              onChange={handleChange}
            />
            {errors.JoiningDate && <p>{errors.JoiningDate}</p>}
          </div>
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Gender:</label>
            <Form.Select
              name="Gender"
              value={employee.Gender}
              onChange={handleChange}
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </Form.Select>
            {errors.Gender && <p>{errors.Gender}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>MaritalStatus:</label>
            <Form.Select
              name="MaritalStatus"
              value={employee.MaritalStatus}
              onChange={handleChange}
            >
              <option value="">Select MaritalStatus</option>
              <option value="marraged">marraged</option>
              <option value="marraged">fff</option>
              <option value="marraged">ff</option>
            </Form.Select>
            {errors.Gender && <p>{errors.Gender}</p>}
          </div>
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Phone Number:</label>
            <Form.Control
              type="text"
              name="PhoneNumber"
              value={employee.PhoneNumber}
              onChange={handleChange}
            />
            {errors.PhoneNumber && <p>{errors.PhoneNumber}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>Alternative Phone Number:</label>
            <Form.Control
              type="text"
              name="AlternativePhoneNumber"
              value={employee.AlternativePhoneNumber}
              onChange={handleChange}
            />
            {errors.AlternativePhoneNumber && (
              <p>{errors.AlternativePhoneNumber}</p>
            )}
          </div>
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Email (Office):</label>
            <Form.Control
              type="email"
              name="EmailOffice"
              value={employee.EmailOffice}
              onChange={handleChange}
            />
            {errors.EmailOffice && <p>{errors.EmailOffice}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>Email (Personal):</label>
            <Form.Control
              type="email"
              name="EmailPersonal"
              value={employee.EmailPersonal}
              onChange={handleChange}
            />
            {errors.EmailPersonal && <p>{errors.EmailPersonal}</p>}
          </div>
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Blood Group:</label>
            <Form.Control
              type="text"
              name="BloodGroup"
              value={employee.BloodGroup}
              onChange={handleChange}
            />
            {errors.BloodGroup && <p>{errors.BloodGroup}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>Aadhaar Number:</label>
            <Form.Control
              type="text"
              name="AadhaarNumber"
              value={employee.AadhaarNumber}
              onChange={handleChange}
            />
            {errors.AadhaarNumber && <p>{errors.AadhaarNumber}</p>}
          </div>
        </Col>
      </Row>

      <div>
        <label>Educational Qualifications:</label>
        {employee.EducationQualification.map((education, index) => (
          <div key={index}>
            <Row>
              <Col>
                <Form.Control
                  type="text"
                  name="degree"
                  value={education.degree}
                  onChange={(event) => handleEducationChange(index, event)}
                  placeholder="Degree"
                />
              </Col>

              <Col>
                <Form.Control
                  type="file"
                  name="pdf"
                  onChange={(event) =>
                    handleCertificationFileChange(index, event)
                  }
                />
                {errors[`EducationQualification[${index}].pdf`] && (
                  <p style={{ color: "red" }}>
                    {errors[`EducationQualification[${index}].pdf`]}
                  </p>
                )}
              </Col>
            </Row>
          </div>
        ))}
      </div>

      <div className="row">
        <div className="col-sm-6">
          <AddressForm
            addressType="AddressPresent"
            addressData={employee.AddressPresent}
            handleAddressChange={handleAddressChange}
            errors={errors}
          />
        </div>
        <div className="col-sm-6">
          <AddressForm
            addressType="AddressPermanent"
            addressData={employee.AddressPermanent}
            handleAddressChange={handleAddressChange}
            errors={errors}
          />
        </div>
      </div>

      <Row>
        <Col>
          <div>
            <label>AccountNumber:</label>
            <Form.Control
              type="number"
              name="AccountNumber"
              value={employee.AccountNumber}
              onChange={handleChange}
            />
            {errors.AccountNumber && <p>{errors.AccountNumber}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>IFSCCode:</label>
            <Form.Control
              type="text"
              name="IFSCCode"
              value={employee.IFSCCode}
              onChange={handleChange}
            />
            {errors.IFSCCode && <p>{errors.IFSCCode}</p>}
          </div>
        </Col>
      </Row>
      <Row>
        <Col>
          <div>
            <label>BankName:</label>
            <Form.Control
              type="text"
              name="BankName"
              value={employee.BankName}
              onChange={handleChange}
            />
            {errors.BankName && <p>{errors.BankName}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>PANNumber:</label>
            <Form.Control
              type="text"
              name="PANNumber"
              value={employee.PANNumber}
              onChange={handleChange}
            />
            {errors.PANNumber && <p>{errors.PANNumber}</p>}
          </div>
        </Col>
      </Row>
      <Row>
        <Col>
          <div>
            <label>workType:</label>
            <Form.Control
              type="text"
              name="workType"
              value={employee.workType}
              onChange={handleChange}
            />
            {errors.workType && <p>{errors.workType}</p>}
          </div>
        </Col>
        <Col>
          <div>
            <label>Status:</label>
            <Form.Control
              type="text"
              name="Status"
              value={employee.Status}
              onChange={handleChange}
            />
            {errors.Status && <p>{errors.Status}</p>}
          </div>
        </Col>
      </Row>

      <Row>
        <Col>
          <div>
            <label>Password:</label>
            <Form.Control
              type="text"
              name="Password"
              value={employee.Password}
              onChange={handleChange}
            />
            {errors.Password && <p>{errors.Password}</p>}
          </div>
        </Col>
        <Col>
        <div >
        <label>ProfileImage:</label>
          <Form.Control
          type="file"
            Name="ProfileImage"
            onChange={handleProfileImageChange}
           
          />
        </div></Col>
      </Row>

      <Button type="submit">Submit</Button>
    </Form>
  );
};

export default EmployeeForm;
