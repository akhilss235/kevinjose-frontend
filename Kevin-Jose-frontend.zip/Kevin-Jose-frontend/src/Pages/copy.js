import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import AddressForm from "../Pages/AddressForm";

const copy = () => {
  const [employee, setEmployee] = useState({
    Name: "",
    EmployeeCode: "",
    Designation: "",
    ProfileImage: null,
    JoiningDate: "",
    Gender: "",
    EducationQualification: [{ pdf: null, degree: "" }],
    PhoneNumber: "",
    MaritalStatus: "",
    AlternativePhoneNumber: "",
    EmailOffice: "",
    EmailPersonal: "",
    BloodGroup: "",
    AadhaarNumber: "",
    AddressPresent: {
      AddressLine1: "",
      AddressLine2: "",
      City: "",
      District: "",
      State: "",
      Country: "",
      ZipCode: "",
    },
    AddressPermanent: {
      AddressLine1: "",
      AddressLine2: "",
      City: "",
      District: "",
      State: "",
      Country: "",
      ZipCode: "",
    },
    AccountNumber: "",
    IFSCCode: "",
    BankName: "",
    PANNumber: "",
    Status: "",
    Username: "ssssssss",
    Password: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleAddressChange = (addressType, field, value) => {
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      [addressType]: {
        ...prevEmployee[addressType],
        [field]: value,
      },
    }));
  };

  const validateForm = () => {
    const errors = {};
    if (!employee.Name.trim()) errors.Name = "Name is required";
    if (!employee.EmployeeCode.trim())
      errors.EmployeeCode = "Employee code is required";
    if (!employee.Password.trim()) errors.Password = "Password is required";
    else if (employee.Password.trim().length < 8)
      errors.Password = "Password should be at least 8 characters long";
    if (!employee.ProfileImage) errors.ProfileImage = "Photo is required";
    if (!employee.JoiningDate) errors.JoiningDate = "Joining date is required";
    if (!employee.Gender) errors.Gender = "Gender is required";
    if (!employee.MaritalStatus)
      errors.MaritalStatus = "Marital status is required";
    if (!employee.PhoneNumber) errors.PhoneNumber = "Phone number is required";
    if (!employee.AlternativePhoneNumber)
      errors.AlternativePhoneNumber = "Alternative phone number is required";
    if (!employee.EmailOffice) errors.EmailOffice = "Office email is required";
    if (!employee.EmailPersonal)
      errors.EmailPersonal = "Personal email is required";
    if (!employee.BloodGroup) errors.BloodGroup = "Blood group is required";
    if (!employee.AadhaarNumber)
      errors.AadhaarNumber = "Aadhaar number is required";
    if (!employee.AccountNumber)
      errors.AccountNumber = "Account number is required";
    if (!employee.IFSCCode) errors.IFSCCode = "IFSC Code is required";
    if (!employee.BankName) errors.BankName = "Bank name is required";
    if (!employee.PANNumber) errors.PANNumber = "PAN number is required";
    if (!employee.Designation) errors.Designation = "Designation is required";

    employee.EducationQualification.forEach((education, index) => {
      if (!education.degree.trim())
        errors[`EducationQualification[${index}].degree`] =
          "Degree is required";
      if (!education.pdf)
        errors[`EducationQualification[${index}].pdf`] =
          "Certification PDF is required";
    });

    if (!employee.AddressPresent.AddressLine1.trim())
      errors.AddressPresent_AddressLine1 = "Present address line 1 is required";
    if (!employee.AddressPermanent.AddressLine1.trim())
      errors.AddressPermanent_AddressLine1 =
        "Permanent address line 1 is required";

    return errors;
  };

  // Handle input change
  const handleChange = (event) => {
    const { name, value } = event.target;
    setEmployee((prevEmployee) => ({ ...prevEmployee, [name]: value }));
  };

  // Handle education qualification change
  const handleEducationChange = (index, event) => {
    const { name, value } = event.target;
    setEmployee((prevEmployee) => ({
      ...prevEmployee,
      EducationQualification: prevEmployee.EducationQualification.map(
        (education, i) =>
          i === index ? { ...education, [name]: value } : education
      ),
    }));
  };

  // Handle certification file change
  const handleCertificationFileChange = (index, event) => {
    const file = event.target.files[0];
    if (file && file.type.toLowerCase() === "application/pdf") {
      setEmployee((prevEmployee) => ({
        ...prevEmployee,
        EducationQualification: prevEmployee.EducationQualification.map(
          (education, i) =>
            i === index ? { ...education, pdf: file } : education
        ),
      }));
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`EducationQualification[${index}].pdf`]: "",
      }));
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`EducationQualification[${index}].pdf`]:
          "Only PDF files are supported",
      }));
    }
  };

  // Handle profile image change
  const handleProfileImageChange = (event) => {
    const file = event.target.files[0];
    setEmployee((prevEmployee) => ({ ...prevEmployee, ProfileImage: file }));
    setErrors((prevErrors) => ({ ...prevErrors, ProfileImage: "" }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    // Validate form
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
  
    try {
      const formData = new FormData();
  
      // Append all simple fields to formData
      formData.append("Name", employee.Name);
      formData.append("EmployeeCode", employee.EmployeeCode);
      formData.append("Designation", employee.Designation);
      formData.append("JoiningDate", employee.JoiningDate);
      formData.append("Gender", employee.Gender);
      formData.append("PhoneNumber", employee.PhoneNumber);
      formData.append("MaritalStatus", employee.MaritalStatus);
      formData.append("AlternativePhoneNumber", employee.AlternativePhoneNumber);
      formData.append("EmailOffice", employee.EmailOffice);
      formData.append("EmailPersonal", employee.EmailPersonal);
      formData.append("BloodGroup", employee.BloodGroup);
      formData.append("AadhaarNumber", employee.AadhaarNumber);
      formData.append("AccountNumber", employee.AccountNumber);
      formData.append("IFSCCode", employee.IFSCCode);
      formData.append("BankName", employee.BankName);
      formData.append("PANNumber", employee.PANNumber);
      formData.append("workType", employee.workType);
      formData.append("Status", employee.Status);
      formData.append("Username", employee.Username);
      formData.append("Password", employee.Password);
      formData.append("EmployeeType", employee.EmployeeType);
  
      // Append ProfileImage file (ensure it's not duplicated)
      if (employee.ProfileImage) {
        formData.append('ProfileImage', employee.ProfileImage);
      }
  
      // Append AddressPresent fields
      Object.keys(employee.AddressPresent).forEach((key) => {
        formData.append(`AddressPresent.${key}`, employee.AddressPresent[key]);
      });
  
      // Append AddressPermanent fields
      Object.keys(employee.AddressPermanent).forEach((key) => {
        formData.append(`AddressPermanent.${key}`, employee.AddressPermanent[key]);
      });
  
      // Append EducationQualification array items
      employee.EducationQualification.forEach((education, index) => {
        formData.append(`EducationQualification[${index}].degree`, education.degree);
        if (education.pdf) {
          formData.append(`EducationQualification[${index}].pdf`, education.pdf);
        }
      });
  
      // Log FormData to check what’s being sent
      for (let [key, value] of formData.entries()) {
        console.log(key, value);
      }
  
      // Send data to the backend
      const response = await axios.post(
        "http://localhost:6060/api/profiles/create/",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
  
      toast.success("Employee added successfully");
      navigate("/Employeeprofile");
    } catch (error) {
      console.error(
        "Error during submission:",
        error.response ? error.response.data : error.message
      );
      toast.error("Failed to add employee. Please try again later.");
    }
  };
  
  return (
    <form onSubmit={handleSubmit}>
      <h2>Employee Registration</h2>
      <div>
        <label>Name:</label>
        <input
          type="text"
          name="Name"
          value={employee.Name}
          onChange={handleChange}
        />
        {errors.Name && <p>{errors.Name}</p>}
      </div>
      <div>


        <label>Employee Code:</label>
        <input
          type="text"
          name="EmployeeCode"
          value={employee.EmployeeCode}
          onChange={handleChange}
        />
        {errors.EmployeeCode && <p>{errors.EmployeeCode}</p>}
      </div>


      
      <div>
        <label>Designation:</label>
        <input
          type="text"
          name="Designation"
          value={employee.Designation}
          onChange={handleChange}
        />
        {errors.Designation && <p>{errors.Designation}</p>}
      </div>
      <div>
        <label>Joining Date:</label>
        <input
          type="date"
          name="JoiningDate"
          value={employee.JoiningDate}
          onChange={handleChange}
        />
        {errors.JoiningDate && <p>{errors.JoiningDate}</p>}
      </div>
      <div>
        <label>Gender:</label>
        <select name="Gender" value={employee.Gender} onChange={handleChange}>
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Others">Other</option>
        </select>
        {errors.Gender && <p>{errors.Gender}</p>}
      </div>
      <div>
        <label>MaritalStatus:</label>
        <select name="MaritalStatus" value={employee.MaritalStatus} onChange={handleChange}>
          <option value="">Select MaritalStatus</option>
          <option value="Married">marraged</option>
          <option value="Unmarried">Unmarried</option>
          <option value="Divorced">Divorced</option>
          <option value="Widowed">Widowed</option>
          <option value="Others">Divorced</option>
        </select>
        {errors.Gender && <p>{errors.Gender}</p>}
      </div>
      <div>
        <label>Phone Number:</label>
        <input
          type="text"
          name="PhoneNumber"
          value={employee.PhoneNumber}
          onChange={handleChange}
        />
        {errors.PhoneNumber && <p>{errors.PhoneNumber}</p>}
      </div>
      <div>
        <label>Alternative Phone Number:</label>
        <input
          type="text"
          name="AlternativePhoneNumber"
          value={employee.AlternativePhoneNumber}
          onChange={handleChange}
        />
        {errors.AlternativePhoneNumber && (
          <p>{errors.AlternativePhoneNumber}</p>
        )}
      </div>
      <div>
        <label>Email (Office):</label>
        <input
          type="email"
          name="EmailOffice"
          value={employee.EmailOffice}
          onChange={handleChange}
        />
        {errors.EmailOffice && <p>{errors.EmailOffice}</p>}
      </div>
      <div>
        <label>Email (Personal):</label>
        <input
          type="email"
          name="EmailPersonal"
          value={employee.EmailPersonal}
          onChange={handleChange}
        />
        {errors.EmailPersonal && <p>{errors.EmailPersonal}</p>}
      </div>
      <div>
        <label>Blood Group:</label>
        <input
          type="text"
          name="BloodGroup"
          value={employee.BloodGroup}
          onChange={handleChange}
        />
        {errors.BloodGroup && <p>{errors.BloodGroup}</p>}
      </div>
      <div>
        <label>Aadhaar Number:</label>
        <input
          type="text"
          name="AadhaarNumber"
          value={employee.AadhaarNumber}
          onChange={handleChange}
        />
        {errors.AadhaarNumber && <p>{errors.AadhaarNumber}</p>}
      </div>
      <div>
        <label>Profile Image:</label>
        <input
          type="file"
          name="ProfileImage"
          onChange={handleProfileImageChange}
        />
        {errors.ProfileImage && <p>{errors.ProfileImage}</p>}
      </div>
      {/* Add other fields similarly */}
      <div>
        <label>Educational Qualifications:</label>
        {employee.EducationQualification.map((education, index) => (
          <div key={index}>
            <input
              type="text"
              name="degree"
              value={education.degree}
              onChange={(event) => handleEducationChange(index, event)}
              placeholder="Degree"
            />
            <input
              type="file"
              name="pdf"
              onChange={(event) => handleCertificationFileChange(index, event)}
            />
            {errors[`EducationQualification[${index}].pdf`] && (
              <p>{errors[`EducationQualification[${index}].pdf`]}</p>
            )}
          </div>
        ))}
      </div>

      <div className="row">
        <div className="col-sm-6">
          <h3>Present Address</h3>
          <AddressForm
            addressType="AddressPresent"
            addressData={employee.AddressPresent}
            handleAddressChange={handleAddressChange}
            errors={errors}
          />
        </div>
        <div className="col-sm-6">
          <h3>Permanent Address</h3>
          <AddressForm
            addressType="AddressPermanent"
            addressData={employee.AddressPermanent}
            handleAddressChange={handleAddressChange}
            errors={errors}
          />
        </div>
      </div>
      <div>
        <label>AccountNumber:</label>
        <input type="number" name="AccountNumber" value={employee.AccountNumber} onChange={handleChange} />
        {errors.AccountNumber && <p>{errors.AccountNumber}</p>}
      </div>
      <div>
        <label>IFSCCode:</label>
        <input type="text" name="IFSCCode" value={employee.IFSCCode} onChange={handleChange} />
        {errors.IFSCCode && <p>{errors.IFSCCode}</p>}
      </div>
      <div>
        <label>BankName:</label>
        <input type="text" name="BankName" value={employee.BankName} onChange={handleChange} />
        {errors.BankName && <p>{errors.BankName}</p>}
      </div>
      <div>
        <label>PANNumber:</label>
        <input type="text" name="PANNumber" value={employee.PANNumber} onChange={handleChange} />
        {errors.PANNumber && <p>{errors.PANNumber}</p>}
      </div>

      <div>
        <label>workType:</label>
        <input type="text" name="workType" value={employee.workType} onChange={handleChange} />
        {errors.workType && <p>{errors.workType}</p>}
      </div>

      <div>
        <label>Status:</label>
        <input type="text" name="Status" value={employee.Status} onChange={handleChange} />
        {errors.Status && <p>{errors.Status}</p>}
      </div>

      <div>
        <label>Password:</label>
        <input type="text" name="Password" value={employee.Password} onChange={handleChange} />
        {errors.Password && <p>{errors.Password}</p>}
      </div>

      <button type="submit">Submit</button>
    </form>
  );
};



export default copy
