// AddressForm.js
import React from 'react';
import Form from "react-bootstrap/Form";

const AddressForm = ({ addressType, addressData, handleAddressChange, errors }) => {
  return (
    <div className='mt-3'>
      <h6>{addressType === "AddressPresent" ? "Present Address" : "Permanent Address"}</h6>
      <div>
        <Form.Control
          type="text"
          value={addressData.AddressLine1}
          onChange={(e) => handleAddressChange(addressType, "AddressLine1", e.target.value)}
        />
        {errors[`${addressType}_AddressLine1`] && <p>{errors[`${addressType}_AddressLine1`]}</p>}
      </div>

      <div>
        <label>City:</label>
        <Form.Control
          type="text"
          value={addressData.City}
          onChange={(e) => handleAddressChange(addressType, "City", e.target.value)}
        />
        {errors[`${addressType}_City`] && <p>{errors[`${addressType}_City`]}</p>}
      </div>
      <div>
        <label>District:</label>
        <Form.Control
          type="text"
          value={addressData.District}
          onChange={(e) => handleAddressChange(addressType, "District", e.target.value)}
        />
      </div>
      <div>
        <label>State:</label>
        <Form.Control
          type="text"
          value={addressData.State}
          onChange={(e) => handleAddressChange(addressType, "State", e.target.value)}
        />
      </div>
      <div>
        <label>Country:</label>
        <Form.Control
          type="text"
          value={addressData.Country}
          onChange={(e) => handleAddressChange(addressType, "Country", e.target.value)}
        />
      </div>
      <div>
        <label>Zip Code:</label>
        <Form.Control
          type="text"
          value={addressData.ZipCode}
          onChange={(e) => handleAddressChange(addressType, "ZipCode", e.target.value)}
        />
        {errors[`${addressType}_ZipCode`] && <p>{errors[`${addressType}_ZipCode`]}</p>}
      </div>
    </div>
  );
};

export default AddressForm;
